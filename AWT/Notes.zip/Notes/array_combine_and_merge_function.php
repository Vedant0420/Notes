<?php 
$a=array("a","b");
$b=array(7,8);
$c=array(37,31);

print_r(array_combine($a,$b));
echo"<br>";
print_r(array_merge($b,$c));

?>